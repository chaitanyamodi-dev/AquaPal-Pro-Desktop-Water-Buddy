import sys
import os
import json
from datetime import datetime, timedelta
from PyQt6.QtCore import Qt, QTimer, QUrl, QPoint
from PyQt6.QtGui import QMovie, QPixmap, QAction, QIcon, QCursor
from PyQt6.QtMultimedia import QSoundEffect
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QComboBox,
    QCheckBox,
    QGroupBox,
    QSystemTrayIcon,
    QMenu,
    QProgressBar,
    QMessageBox,
)

# --- CONFIGURATION & STYLES ---
COMBO_STYLE = """
    QComboBox { border: 1px solid #aaaaaa; border-radius: 4px; padding: 6px 30px 6px 10px; background-color: #ffffff; color: #000000 !important; font-family: 'Segoe UI'; font-size: 14px; font-weight: 500; min-height: 20px; }
    QComboBox::drop-down { subcontrol-origin: padding; subcontrol-position: top right; width: 30px; border-left: 1px solid #aaaaaa; border-top-right-radius: 3px; border-bottom-right-radius: 3px; background-color: #f8f8f8; }
    QComboBox::down-arrow { image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24'><path fill='%23000000' d='M7 10l5 5 5-5z'/></svg>"); width: 12px; height: 12px; margin-right: 5px; }
    QComboBox QAbstractItemView { background-color: #ffffff; color: #000000; border: 1px solid #aaaaaa; selection-background-color: #0078d4; selection-color: #ffffff; padding: 5px; outline: none; }
"""


class DataManager:
    """Handles saving/loading hydration data and achievements"""

    def __init__(self):
        self.file = "hydration_data.json"
        self.data = self.load()

    def load(self):
        if os.path.exists(self.file):
            with open(self.file, "r") as f:
                return json.load(f)
        return {"daily": {}, "streak": 0, "last_date": None, "achievements": []}

    def save(self):
        with open(self.file, "w") as f:
            json.dump(self.data, f, indent=2)

    def get_today_count(self):
        today = datetime.now().strftime("%Y-%m-%d")
        return self.data["daily"].get(today, 0)

    def add_glass(self, goal=8):
        today = datetime.now().strftime("%Y-%m-%d")
        current = self.data["daily"].get(today, 0) + 1
        self.data["daily"][today] = current

        # Update streak logic
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        if self.data["last_date"] == yesterday or self.data["last_date"] == today:
            if self.data["last_date"] != today:
                self.data["streak"] += 1
        else:
            self.data["streak"] = 1
        self.data["last_date"] = today

        # Check achievements
        new_achievements = []
        if current == 1 and "first_sip" not in self.data["achievements"]:
            new_achievements.append(("first_sip", "First Sip! 🥤"))
        if current >= goal and "goal_crusher" not in self.data["achievements"]:
            new_achievements.append(("goal_crusher", "Goal Crusher! 🎯"))
        if self.data["streak"] >= 7 and "week_warrior" not in self.data["achievements"]:
            new_achievements.append(("week_warrior", "Week Warrior! 🔥"))

        for ach_id, ach_name in new_achievements:
            self.data["achievements"].append(ach_id)

        self.save()
        return current, new_achievements

    def get_progress(self, goal=8):
        return min(self.get_today_count() / goal, 1.0)


class AquaPalWidget(QWidget):
    """Desktop Widget Mode: Always visible progress tracker"""

    def __init__(self, data_manager):
        super().__init__()
        self.dm = data_manager
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(200, 80)
        self.drag_pos = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)

        self.label = QLabel("💧 0 / 8 Glasses")
        self.label.setStyleSheet("color: white; font-weight: bold; font-size: 14px;")
        layout.addWidget(self.label)

        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(8)
        self.bar.setStyleSheet("""
            QProgressBar { border: none; background-color: rgba(255,255,255,0.2); border-radius: 4px; }
            QProgressBar::chunk { background-color: #00E5FF; border-radius: 4px; }
        """)
        layout.addWidget(self.bar)

        self.setStyleSheet(
            "background-color: rgba(0,0,0,0.6); border-radius: 10px; border: 1px solid rgba(255,255,255,0.1);"
        )
        self.update_display()

    def update_display(self):
        count = self.dm.get_today_count()
        pct = int(self.dm.get_progress() * 100)
        self.label.setText(f" {count} / 8 Glasses")
        self.bar.setValue(pct)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.drag_pos = (
                event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            )
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton and self.drag_pos:
            self.move(event.globalPosition().toPoint() - self.drag_pos)


class AquaPalSettings(QMainWindow):
    def __init__(self):
        super().__init__()
        self.dm = DataManager()
        self.selected_character = "girl"
        self.selected_theme = "dark"
        self.sound_enabled = True
        self.widget_mode = False
        self.widget = None
        self.tray_icon = None
        self.is_paused = False
        self.init_ui()
        self.init_tray()

    def init_ui(self):
        self.setWindowTitle("AquaPal Pro - Settings")
        self.setFixedSize(450, 600)
        self.setStyleSheet("QMainWindow { background-color: #f0f0f0; }")

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(12)
        layout.setContentsMargins(20, 20, 20, 20)

        title = QLabel("AquaPal Pro Settings")
        title.setStyleSheet(
            "font-size: 22px; font-weight: bold; color: #111111; margin-bottom: 5px;"
        )
        layout.addWidget(title, alignment=Qt.AlignmentFlag.AlignCenter)

        # Daily Stats Preview
        stats_box = QGroupBox("Today's Progress")
        stats_box.setStyleSheet(
            "QGroupBox { border: 2px solid #0078d4; border-radius: 8px; margin-top: 10px; padding-top: 15px; font-weight: bold; color: #0078d4; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }"
        )
        stats_layout = QVBoxLayout()
        self.stats_label = QLabel(
            f"Glasses: {self.dm.get_today_count()} / 8 | Streak: {self.dm.data['streak']} days 🔥"
        )
        self.stats_label.setStyleSheet("font-size: 14px; color: #333;")
        stats_layout.addWidget(self.stats_label)
        stats_box.setLayout(stats_layout)
        layout.addWidget(stats_box)

        # Character & Theme (Simplified for brevity, same as before)
        char_group = QGroupBox("Hydration Buddy")
        char_group.setStyleSheet(
            "QGroupBox { border: 2px solid #cccccc; border-radius: 8px; margin-top: 10px; padding-top: 15px; font-weight: bold; color: #222222; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }"
        )
        char_layout = QVBoxLayout()
        self.character_dropdown = QComboBox()
        self.character_dropdown.addItems(
            ["Girl Photo", "Water Droplet", "Frog Friend", "Robot Buddy"]
        )
        self.character_dropdown.setStyleSheet(COMBO_STYLE)
        self.character_dropdown.currentIndexChanged.connect(
            lambda i: setattr(
                self, "selected_character", ["girl", "droplet", "frog", "robot"][i]
            )
        )
        char_layout.addWidget(self.character_dropdown)
        char_group.setLayout(char_layout)
        layout.addWidget(char_group)

        theme_group = QGroupBox("Notification Theme")
        theme_group.setStyleSheet(
            "QGroupBox { border: 2px solid #cccccc; border-radius: 8px; margin-top: 10px; padding-top: 15px; font-weight: bold; color: #222222; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }"
        )
        theme_layout = QVBoxLayout()
        self.theme_dropdown = QComboBox()
        self.theme_dropdown.addItems(
            ["Dark Mode", "Light Mode", "Ocean Blue", "Pink Pastel"]
        )
        self.theme_dropdown.setStyleSheet(COMBO_STYLE)
        self.theme_dropdown.currentIndexChanged.connect(
            lambda i: setattr(
                self, "selected_theme", ["dark", "light", "ocean", "pink"][i]
            )
        )
        theme_layout.addWidget(self.theme_dropdown)
        theme_group.setLayout(theme_layout)
        layout.addWidget(theme_group)

        # Widget Mode Toggle
        self.widget_checkbox = QCheckBox("Enable Desktop Widget (Always Visible)")
        self.widget_checkbox.setStyleSheet(
            "font-family: 'Segoe UI'; font-size: 14px; color: #222222; font-weight: 500;"
        )
        self.widget_checkbox.stateChanged.connect(self.toggle_widget)
        layout.addWidget(self.widget_checkbox)

        # Sound & Smart Hours
        self.sound_checkbox = QCheckBox("Enable Sound Notifications")
        self.sound_checkbox.setChecked(True)
        self.sound_checkbox.setStyleSheet(
            "font-family: 'Segoe UI'; font-size: 14px; color: #222222;"
        )
        self.sound_checkbox.stateChanged.connect(
            lambda s: setattr(self, "sound_enabled", s == 2)
        )
        layout.addWidget(self.sound_checkbox)

        self.smart_hours_checkbox = QCheckBox("Smart Work Hours (9 AM - 5 PM, Mon-Fri)")
        self.smart_hours_checkbox.setChecked(True)
        self.smart_hours_checkbox.setStyleSheet(
            "font-family: 'Segoe UI'; font-size: 14px; color: #222222;"
        )
        layout.addWidget(self.smart_hours_checkbox)

        # Interval
        self.interval_dropdown = QComboBox()
        self.interval_dropdown.addItem("10 Seconds (Test)", 10000)
        self.interval_dropdown.addItem("15 Minutes", 900000)
        self.interval_dropdown.addItem("30 Minutes", 1800000)
        self.interval_dropdown.addItem("1 Hour", 3600000)
        self.interval_dropdown.setStyleSheet(COMBO_STYLE)
        layout.addWidget(self.interval_dropdown, alignment=Qt.AlignmentFlag.AlignCenter)

        # Start Button
        self.start_btn = QPushButton("Start AquaPal Pro")
        self.start_btn.setMinimumHeight(50)
        self.start_btn.setStyleSheet(
            "QPushButton { background-color: #0066CC; color: white; border: 2px solid #004499; border-radius: 8px; padding: 12px; font-size: 16px; font-weight: bold; } QPushButton:hover { background-color: #0077EE; }"
        )
        self.start_btn.clicked.connect(self.start_app)
        layout.addWidget(self.start_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        self.reminder_timer = QTimer()
        self.reminder_timer.timeout.connect(self.show_notification)

    def init_tray(self):
        self.tray_icon = QSystemTrayIcon(self)
        # Use a generic icon if you don't have one, or create a simple one
        self.tray_icon.setIcon(QIcon.fromTheme("water"))
        self.tray_icon.setToolTip("AquaPal Pro")

        menu = QMenu()
        act_resume = QAction("▶ Resume Reminders", self)
        act_resume.triggered.connect(self.resume_reminders)
        act_pause = QAction("⏸ Pause Reminders", self)
        act_pause.triggered.connect(self.pause_reminders)
        act_log = QAction("💧 Quick Log Glass", self)
        act_log.triggered.connect(self.quick_log)
        act_exit = QAction("❌ Exit AquaPal", self)
        act_exit.triggered.connect(QApplication.quit)

        menu.addAction(act_resume)
        menu.addAction(act_pause)
        menu.addSeparator()
        menu.addAction(act_log)
        menu.addSeparator()
        menu.addAction(act_exit)

        self.tray_icon.setContextMenu(menu)
        self.tray_icon.show()

    def toggle_widget(self, state):
        if state == 2:
            if not self.widget:
                self.widget = AquaPalWidget(self.dm)
                self.widget.show()
        else:
            if self.widget:
                self.widget.close()
                self.widget = None

    def start_app(self):
        interval = self.interval_dropdown.currentData()
        self.reminder_timer.start(interval)
        self.hide()
        if self.widget_checkbox.isChecked() and not self.widget:
            self.widget = AquaPalWidget(self.dm)
            self.widget.show()

    def pause_reminders(self):
        self.is_paused = True
        self.reminder_timer.stop()
        self.tray_icon.showMessage(
            "AquaPal Paused", "Reminders are temporarily stopped."
        )

    def resume_reminders(self):
        self.is_paused = False
        interval = self.interval_dropdown.currentData()
        self.reminder_timer.start(interval)
        self.tray_icon.showMessage("AquaPal Resumed", "Back to staying hydrated!")

    def quick_log(self):
        count, achievements = self.dm.add_glass()
        msg = f"Logged! Total today: {count}"
        if achievements:
            msg += f"\n🏆 Unlocked: {achievements[0][1]}"
        self.tray_icon.showMessage("Glass Logged! 💧", msg)
        if self.widget:
            self.widget.update_display()

    def show_notification(self):
        if self.is_paused:
            return
        self.reminder_timer.stop()

        if self.smart_hours_checkbox.isChecked():
            now = datetime.now()
            if now.weekday() >= 5 or now.hour < 9 or now.hour >= 17:
                self.schedule_next_workday()
                return

        popup = AquaPalToast(
            self,
            self.selected_character,
            self.selected_theme,
            self.sound_enabled,
            self.dm,
        )
        popup.show()

    def schedule_next_workday(self):
        now = datetime.now()
        target = now.replace(hour=9, minute=0, second=0, microsecond=0)
        if now >= target:
            target += timedelta(days=1)
        while target.weekday() >= 5:
            target += timedelta(days=1)
        delay_ms = int((target - now).total_seconds() * 1000)
        self.reminder_timer.start(delay_ms)


class AquaPalToast(QWidget):
    def __init__(self, settings_window, character, theme, sound_enabled, data_manager):
        super().__init__()
        self.sw = settings_window
        self.character = character
        self.theme = theme
        self.sound_enabled = sound_enabled
        self.dm = data_manager
        self.happy_pixmap = None
        self.init_ui()
        self.play_sound()

    def get_colors(self):
        themes = {
            "dark": {
                "bg": "#1e1e1e",
                "border": "#3a3a3a",
                "text": "#00E5FF",
                "btn1": "#0078d4",
                "btn1t": "#fff",
                "btn2": "#333",
                "btn2t": "#fff",
                "btn2b": "#666",
            },
            "light": {
                "bg": "#fff",
                "border": "#ccc",
                "text": "#0066CC",
                "btn1": "#0078d4",
                "btn1t": "#fff",
                "btn2": "#f0f0f0",
                "btn2t": "#333",
                "btn2b": "#999",
            },
            "ocean": {
                "bg": "#E0F7FA",
                "border": "#4DD0E1",
                "text": "#006064",
                "btn1": "#00ACC1",
                "btn1t": "#fff",
                "btn2": "#B2EBF2",
                "btn2t": "#006064",
                "btn2b": "#4DD0E1",
            },
            "pink": {
                "bg": "#FCE4EC",
                "border": "#F48FB1",
                "text": "#880E4F",
                "btn1": "#EC407A",
                "btn1t": "#fff",
                "btn2": "#F8BBD9",
                "btn2t": "#880E4F",
                "btn2b": "#F48FB1",
            },
        }
        return themes.get(self.theme, themes["dark"])

    def get_smart_message(self):
        hour = datetime.now().hour
        if hour < 12:
            return "Good morning! Start hydrated! ️"
        elif hour < 17:
            return "Keep up the great work! "
        else:
            return "Wind down with some water! 🌙"

    def play_sound(self):
        if not self.sound_enabled:
            return
        try:
            sf = f"sound_{self.theme}.wav"
            if os.path.exists(sf):
                se = QSoundEffect()
                se.setSource(QUrl.fromLocalFile(sf))
                se.setVolume(0.5)
                se.play()
            else:
                import winsound

                winsound.MessageBeep(winsound.MB_ICONASTERISK)
        except:
            pass

    def init_ui(self):
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.SubWindow
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(320, 420)
        c = self.get_colors()

        lay = QVBoxLayout(self)
        lay.setContentsMargins(15, 15, 15, 15)
        lay.setSpacing(15)

        self.txt = QLabel(self.get_smart_message())
        self.txt.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.txt.setStyleSheet(
            f"QLabel{{color:{c['text']};font-family:'Segoe UI';font-size:20px;font-weight:800;background:transparent;padding:5px;}}"
        )
        lay.addWidget(self.txt)

        self.img = QLabel()
        self.img.setFixedSize(160, 160)
        self.img.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.img.setStyleSheet("background:transparent;")

        # Load Happy Image
        hp = QPixmap("character_happy.png")
        if hp.isNull():
            hp = QPixmap("character_happy.jpg")
        if not hp.isNull():
            self.happy_pixmap = hp.scaled(
                self.img.size(),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )

        # Load Normal Image
        if self.character == "girl":
            mv = QMovie("character.gif")
            if mv.isValid() and mv.frameCount() > 1:
                mv.setScaledSize(self.img.size())
                self.img.setMovie(mv)
                mv.start()
                self.movie = mv
            else:
                px = QPixmap("character.png")
                if px.isNull():
                    px = QPixmap("character.jpg")
                if not px.isNull():
                    self.img.setPixmap(
                        px.scaled(
                            self.img.size(),
                            Qt.AspectRatioMode.KeepAspectRatio,
                            Qt.TransformationMode.SmoothTransformation,
                        )
                    )
                else:
                    self.img.setText("")
                    self.img.setStyleSheet("font-size:80px;background:transparent;")
        else:
            emojis = {"droplet": "", "frog": "🐸", "robot": ""}
            self.img.setText(emojis.get(self.character, "💧"))
            self.img.setStyleSheet("font-size:100px;background:transparent;")

        lay.addWidget(self.img, alignment=Qt.AlignmentFlag.AlignCenter)

        bl = QHBoxLayout()
        bl.setSpacing(10)
        self.btn_drank = QPushButton("✓ Drank It")
        self.btn_snooze = QPushButton(" Snooze")

        self.btn_drank.setStyleSheet(
            f"QPushButton{{background-color:{c['btn1']};color:{c['btn1t']};border-radius:6px;padding:10px 15px;font-family:'Segoe UI';font-size:14px;font-weight:700;border:none;}} QPushButton:hover{{background-color:#106ebe;}}"
        )
        self.btn_snooze.setStyleSheet(
            f"QPushButton{{background-color:{c['btn2']};color:{c['btn2t']};border-radius:6px;padding:10px 15px;font-family:'Segoe UI';font-size:14px;font-weight:700;border:2px solid {c['btn2b']};}} QPushButton:hover{{background-color:#444;}}"
        )

        self.btn_drank.clicked.connect(self.action_drank)
        self.btn_snooze.clicked.connect(self.action_snooze)
        bl.addWidget(self.btn_drank)
        bl.addWidget(self.btn_snooze)
        lay.addLayout(bl)

        self.setStyleSheet(
            f"AquaPalToast{{background-color:{c['bg']};border:2px solid {c['border']};border-radius:16px;}}"
        )

        sg = QApplication.primaryScreen().geometry()
        self.move(sg.width() - self.width() - 30, sg.height() - self.height() - 60)

        self.auto_timer = QTimer()
        self.auto_timer.timeout.connect(self.close)
        self.auto_timer.start(30000)

    def action_drank(self):
        self.auto_timer.stop()
        self.btn_drank.setEnabled(False)
        self.btn_snooze.setEnabled(False)
        self.btn_drank.setText("✓ Great Job!")
        self.btn_drank.setStyleSheet(
            "QPushButton{background-color:#28a745;color:white;border-radius:6px;padding:10px 15px;font-weight:700;}"
        )
        self.txt.setText("Yay! Great job! 🎉")

        if self.happy_pixmap:
            self.img.setPixmap(self.happy_pixmap)
        else:
            self.img.setText("")
            self.img.setStyleSheet("font-size:100px;background:transparent;")

        # Update Data & Widget
        count, achievements = self.dm.add_glass()
        if self.sw.widget:
            self.sw.widget.update_display()

        # Show Achievement Toast if any
        if achievements:
            self.sw.tray_icon.showMessage(
                "Achievement Unlocked! 🏆", achievements[0][1]
            )

        QTimer.singleShot(1500, lambda: [self.close(), self.sw.start_app()])

    def action_snooze(self):
        self.auto_timer.stop()
        self.close()
        self.sw.reminder_timer.start(600000)  # 10 min snooze


if __name__ == "__main__":
    app = QApplication(sys.argv)
    # Ensure we don't quit when main window is hidden
    app.setQuitOnLastWindowClosed(False)
    window = AquaPalSettings()
    window.show()
    sys.exit(app.exec())
